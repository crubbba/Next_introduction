module.exports=[26101,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_events_%5Bid%5D_page_actions_b8b84f6a.js.map