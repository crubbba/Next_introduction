module.exports=[10086,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_users_create_page_actions_b5ba6be3.js.map