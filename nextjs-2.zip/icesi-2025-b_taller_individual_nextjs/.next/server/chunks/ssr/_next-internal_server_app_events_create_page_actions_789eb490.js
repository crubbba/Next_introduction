module.exports=[87449,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_events_create_page_actions_789eb490.js.map