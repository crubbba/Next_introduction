module.exports=[30998,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_events_page_actions_4a40e661.js.map