module.exports=[49554,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_events_%5Bid%5D_edit_page_actions_2365ac77.js.map